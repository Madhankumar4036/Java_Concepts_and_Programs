Implementation of Patterns using Loops

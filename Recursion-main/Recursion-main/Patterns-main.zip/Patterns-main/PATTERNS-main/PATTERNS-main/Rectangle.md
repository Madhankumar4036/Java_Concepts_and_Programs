import java.util.*;
public class Rectangle
{
	public static void main(String[] args) {
	    Scanner ip=new Scanner(System.in);
	    int n=ip.nextInt();
	    int m=ip.nextInt();
	    for(int i=1;i<=n;i++){
	        for(int j=1;j<=m;j++){
	            System.out.print("x ");
	        }
	        System.out.println(" ");
	    }
	
	}
}
